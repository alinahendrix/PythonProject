# Student ID: 010642667
# Name: Alina Hendrix

import datetime
from Truck import Truck
from Package import Package
from HashTable import CreateHashMap
from utils import load_csv, extract_address, distance_between_points

# Load CSV data
CSV_Distance = load_csv("CSV/Distance.csv")
CSV_Address = load_csv("CSV/Addresses.csv")
CSV_Package = load_csv("CSV/Packages.csv")

# Create and fill package hash table
package_hash_table = CreateHashMap()
for row in CSV_Package.values():
    package = Package(int(row[0]), row[1], row[2], row[3], row[4], row[5], row[6])
    package_hash_table.insert(package.ID, package)

# Add delayed arrival metadata
for delayed_id in [6, 25, 28, 32]:
    pkg = package_hash_table.lookup(delayed_id)
    pkg.arrival_time = datetime.timedelta(hours=9, minutes=5)
    package_hash_table.insert(pkg.ID, pkg)

# Corrected address logic for package 9
pkg9 = package_hash_table.lookup(9)
pkg9.old_address = "300 State St"
pkg9.address = "410 S. State St."
pkg9.city = "Salt Lake City"
pkg9.state = "UT"
pkg9.zipcode = "84111"
pkg9.address_update_time = datetime.timedelta(hours=10, minutes=20)
package_hash_table.insert(pkg9.ID, pkg9)

# Define trucks
truck_data = [
    {"packages": [], "depart_time": datetime.timedelta(hours=8)},
    {"packages": [], "depart_time": datetime.timedelta(hours=9, minutes=5)},
    {"packages": [], "depart_time": None},
]
trucks = [Truck(16, 18, None, data["packages"], 0.0, "4001 South 700 East", data["depart_time"]) for data in truck_data]

# Package assignment
priority_packages = sorted(package_hash_table.data.values(), key=lambda p: p.deadline_time)
truck_2_priority = {38, 36, 3}
grouped_packages = {14, 15, 19, 13, 16}

# Assign grouped packages to Truck 1
for package in priority_packages[:]:
    if package.ID in grouped_packages:
        trucks[0].packages.append(package.ID)
        package.truck_id = 1
        package_hash_table.insert(package.ID, package)
        priority_packages.remove(package)

# Assign Truck 2 specific packages
for package in priority_packages[:]:
    if package.ID in truck_2_priority:
        trucks[1].packages.append(package.ID)
        package.truck_id = 2
        package_hash_table.insert(package.ID, package)
        priority_packages.remove(package)

# Fill Trucks 1 and 2 (skip delayed packages for early trucks)
for truck_index, truck in enumerate(trucks[:2]):
    while priority_packages and len(truck.packages) < 16:
        package = priority_packages.pop(0)
        if package.arrival_time and package.arrival_time > truck.depart_time:
            priority_packages.append(package)
            continue
        truck.packages.append(package.ID)
        package.truck_id = truck_index + 1
        package_hash_table.insert(package.ID, package)

# Assign remaining packages to Truck 3
for package in priority_packages:
    trucks[2].packages.append(package.ID)
    package.truck_id = 3
    package_hash_table.insert(package.ID, package)

# Add Package 9 to Truck 3
trucks[2].packages.append(pkg9.ID)
pkg9.truck_id = 3
package_hash_table.insert(pkg9.ID, pkg9)

# Nearest Neighbor Delivery Logic
def deliver_packages(truck):
    not_delivered = [package_hash_table.lookup(pid) for pid in truck.packages]
    truck.packages.clear()

    while not_delivered:
        next_package = min(not_delivered, key=lambda p: distance_between_points(
            extract_address(truck.address, CSV_Address),
            extract_address(p.address, CSV_Address),
            CSV_Distance))
        truck.packages.append(next_package.ID)
        not_delivered.remove(next_package)

        distance = distance_between_points(
            extract_address(truck.address, CSV_Address),
            extract_address(next_package.address, CSV_Address),
            CSV_Distance)

        truck.mileage += distance
        truck.address = next_package.address
        travel_time = datetime.timedelta(hours=distance / 18)
        if travel_time.total_seconds() == 0:
            travel_time = datetime.timedelta(minutes=1)
        truck.time += travel_time
        next_package.departure_time = truck.depart_time
        next_package.delivery_time = truck.time

# Deliver for Trucks 1 & 2
for truck in trucks[:2]:
    deliver_packages(truck)

# Set Truck 3 departure time
truck_1_return = trucks[0].depart_time + datetime.timedelta(hours=trucks[0].mileage / 18)
truck_2_return = trucks[1].depart_time + datetime.timedelta(hours=trucks[1].mileage / 18)
trucks[2].depart_time = max(datetime.timedelta(hours=11, minutes=30),
                            min(truck_1_return, truck_2_return),
                            datetime.timedelta(hours=10, minutes=20))
trucks[2].time = trucks[2].depart_time
deliver_packages(trucks[2])

# Display summary
print("WGUPS - Western Governors University Parcel Service")
print(f"Total mileage for all trucks: {sum(t.mileage for t in trucks)}")

# Supervisor query interface
user_input = input("To check package status, type 'time': ")
if user_input.lower() == "time":
    try:
        h, m, s = map(int, input("Enter a time (HH:MM:SS): ").split(":"))
        current_time = datetime.timedelta(hours=h, minutes=m, seconds=s)
        option = input("Type 'solo' for one package or 'all' for all packages: ")

        if option.lower() == "solo":
            pid = int(input("Enter package ID: "))
            p = package_hash_table.lookup(pid)
            p.update_status(current_time)
            print(p.__str__(current_time))

        elif option.lower() == "all":
            for p in package_hash_table.data.values():
                p.update_status(current_time)
                print(p.__str__(current_time))
    except ValueError:
        print("Invalid time format. Closing program.")
else:
    print("Invalid entry. Closing program.")
