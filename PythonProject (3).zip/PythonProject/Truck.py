#Create Truck class
import datetime
class Truck:
    def __init__(self, capacity, speed, load, packages, mileage, address, depart_time):
        self.capacity = capacity
        self.speed = speed
        self.load = load or 0
        self.packages = packages if packages is not None else []
        self.mileage = mileage
        self.address = address
        self.depart_time = depart_time
        self.time = depart_time if depart_time else datetime.timedelta(hours=8)  # Default to 8:00 AM if None
        #end debug

    def add_package(self, package_id):
        """Adds a package to the truck."""
        self.packages.add(package_id)

    def remove_package(self, package_id):
        """Removes a package from the truck."""
        self.packages.discard(package_id)  # Prevents errors if package doesn't exist

    def __str__(self):
        return f"Truck at {self.address} with {len(self.packages)} packages"

