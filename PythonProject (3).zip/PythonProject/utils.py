import csv
#imports data from csv
def load_csv(filename):
    """Loads a CSV file into a dictionary for quick lookups."""
    with open(filename) as file:
        reader = list(csv.reader(file))  # Convert to list first
        return {i: {j: row[j] for j in range(len(row))} for i, row in enumerate(reader)}

def extract_address(address, CSV_Address):
    """Finds the address index in the CSV file."""
    return next((int(row[0]) for row in CSV_Address.values() if address in row[2]), None)

def distance_between_points(x, y, CSV_Distance):
    """Finds the distance between two addresses/points."""
    distance = CSV_Distance.get(x, {}).get(y, '') or CSV_Distance.get(y, {}).get(x, '')
    return float(distance) if distance else 0.0