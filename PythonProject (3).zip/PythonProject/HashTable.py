class CreateHashMap:
    def __init__(self):
        self.data = {}  # Store packages in a dictionary

    def insert(self, key, item):
        """Inserts or updates a package in the hash map."""
        self.data[key] = item

#Part B. Lookup function using package ID and returning required data
    def lookup(self, key):
        """Retrieves a package by its ID."""
        return self.data.get(key, None)  # Uses .get() for efficient lookup

    def remove(self, key):
        """Removes a package from the hash map."""
        if key in self.data:
            del self.data[key]