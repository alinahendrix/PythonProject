import datetime
# Create class for packages
class Package:
    def __init__(self, ID, address, city, state, zipcode, deadline_time, weight, status="At Hub"):
        self.ID = ID
        self.address = address
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.deadline_time = deadline_time
        self.weight = weight
        self.status = status
        self.departure_time = None
        self.delivery_time = None
        self.truck_id = None

        self.arrival_time = None  # For delayed packages

        self.old_address = None  # Add this for Package 9
        self.address_update_time = None  # When the address becomes valid

    def get_current_address(self, current_time):
        if self.address_update_time and current_time < self.address_update_time:
            return self.old_address
        return self.address

    def update_status(self, current_time):
        # Package hasn't arrived at hub yet
        if self.arrival_time and current_time < self.arrival_time:
            self.status = "In transit to Hub"

        # Package 9's special case: address unknown until 10:20 AM
        elif self.ID == 9 and self.address_update_time and current_time < self.address_update_time:
            self.status = "At Hub - Awaiting address correction"

        # Delivered
        elif self.delivery_time and current_time >= self.delivery_time:
            self.status = "Delivered"

        # En Route
        elif self.departure_time and current_time >= self.departure_time:
            self.status = "En Route"

        # At Hub (arrived, but not departed yet)
        else:
            self.status = "At Hub"

    def __str__(self, current_time=None):
        address = self.address
        city = self.city
        state = self.state
        zipcode = self.zipcode

        if self.address_update_time and self.old_address and current_time:
            if current_time < self.address_update_time:
                address = self.old_address
                city = "Salt Lake City"
                state = "UT"
                zipcode = "84103"  # Zip that matches the old incorrect address

        return (f"Package {self.ID} (Truck {self.truck_id}): {address}, {city}, {state} {zipcode}\n"
                f"Deadline: {self.deadline_time}, Weight: {self.weight} kg\n"
                f"Status: {self.status}, Departure: {self.departure_time}, Delivery: {self.delivery_time}")
